int seed_prng(void);


void fill_random_block(char *bloc,int size_block);
