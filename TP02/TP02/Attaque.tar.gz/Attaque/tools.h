void affiche_bloc(unsigned char *, int) ;
